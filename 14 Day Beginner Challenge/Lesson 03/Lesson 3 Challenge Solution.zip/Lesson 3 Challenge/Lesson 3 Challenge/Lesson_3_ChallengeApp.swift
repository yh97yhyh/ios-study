//
//  Lesson_3_ChallengeApp.swift
//  Lesson 3 Challenge
//
//  Created by Christopher Ching on 2020-11-16.
//

import SwiftUI

@main
struct Lesson_3_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
