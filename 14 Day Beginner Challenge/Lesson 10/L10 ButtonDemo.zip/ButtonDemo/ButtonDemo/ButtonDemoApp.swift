//
//  ButtonDemoApp.swift
//  ButtonDemo
//
//  Created by Christopher Ching on 2020-12-08.
//

import SwiftUI

@main
struct ButtonDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
