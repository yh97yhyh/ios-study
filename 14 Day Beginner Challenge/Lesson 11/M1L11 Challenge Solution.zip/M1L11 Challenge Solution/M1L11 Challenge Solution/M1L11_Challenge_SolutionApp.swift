//
//  M1L11_Challenge_SolutionApp.swift
//  M1L11 Challenge Solution
//
//  Created by Christopher Ching on 2021-04-08.
//

import SwiftUI

@main
struct M1L11_Challenge_SolutionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
