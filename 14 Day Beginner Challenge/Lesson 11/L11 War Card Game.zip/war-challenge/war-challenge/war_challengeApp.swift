//
//  war_challengeApp.swift
//  war-challenge
//
//  Created by Christopher Ching on 2020-10-28.
//

import SwiftUI

@main
struct war_challengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
