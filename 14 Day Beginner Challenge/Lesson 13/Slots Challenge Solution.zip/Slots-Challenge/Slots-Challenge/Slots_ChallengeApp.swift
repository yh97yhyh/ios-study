//
//  Slots_ChallengeApp.swift
//  Slots-Challenge
//
//  Created by Christopher Ching on 2020-12-16.
//

import SwiftUI

@main
struct Slots_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
