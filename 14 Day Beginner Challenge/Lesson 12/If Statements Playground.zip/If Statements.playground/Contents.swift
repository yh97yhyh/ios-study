
let a = 1
let b = 2
let c = 3
let d = "hello"
let e = false
let f = true
let g = true
let h = "world"


// && <- And
// || <- Or
// >, <, >=, <=, ==, !=
// !
if (c == 10 || b < 4) && !(a != 0) {
    print("Hello World")
}
else if d > h {
    
}
else if !g {
    
}
else {
    print("Catch All")
}
