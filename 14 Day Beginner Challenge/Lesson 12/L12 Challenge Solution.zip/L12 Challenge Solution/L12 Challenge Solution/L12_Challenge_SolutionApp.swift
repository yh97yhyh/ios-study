//
//  L12_Challenge_SolutionApp.swift
//  L12 Challenge Solution
//
//  Created by Christopher Ching on 2020-12-15.
//

import SwiftUI

@main
struct L12_Challenge_SolutionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
